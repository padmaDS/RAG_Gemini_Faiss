from typing import List

import streamlit as st
from langchain_community.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings

from src.vector_store import get_conversational_chain

import os

import os
from src.vector_store import get_vector_store

def user_input(user_question: str, text_chunks=None):
    """Handles user input and ensures the FAISS index is available."""
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    
    index_path = "faiss_index/index.faiss"
    if not os.path.exists(index_path):
        if text_chunks is None:
            st.error("FAISS index not found, and no text chunks provided to recreate it.")
            return
        st.warning("FAISS index not found. Recreating...")
        get_vector_store(text_chunks)
        st.success("FAISS index recreated.")
    
    # Load the FAISS index
    try:
        new_db = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
        docs = new_db.similarity_search(user_question)
        chain = get_conversational_chain()
        response = chain(
            {"input_documents": docs, "question": user_question}, return_only_outputs=True
        )
        st.write("Reply: ", response["output_text"])
    except Exception as e:
        st.error(f"Failed to load FAISS index: {e}")
